﻿
Partial Class Account_ChangePassword
    Inherits System.Web.UI.Page
    'Honestly, I don't have anything that links to the "change password" pages, but I'll leave them here in case I 
    'want to do something with them later.
End Class
