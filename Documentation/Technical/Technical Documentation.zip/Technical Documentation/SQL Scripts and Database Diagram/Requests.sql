USE [C:\USERS\MISTERBRISTLES\DOCUMENTS\VISUAL STUDIO 2010\WEBSITES\FINALPROJECT\APP_DATA\ASPNETDB.MDF]
GO

/****** Object:  Table [dbo].[Requests]    Script Date: 11/29/2016 11:55:35 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Requests](
	[RequestID] [int] IDENTITY(1,1) NOT NULL,
	[PatronID] [uniqueidentifier] NOT NULL,
	[LibraryFromID] [uniqueidentifier] NOT NULL,
	[LibraryToID] [uniqueidentifier] NOT NULL,
	[MediaID] [int] NOT NULL,
	[Shipped] [bit] NULL,
 CONSTRAINT [PK_Requests] PRIMARY KEY CLUSTERED 
(
	[RequestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Requests] ADD  CONSTRAINT [DF_Requests_Shipped]  DEFAULT ((0)) FOR [Shipped]
GO

ALTER TABLE [dbo].[Requests]  WITH CHECK ADD  CONSTRAINT [FK_Requests_aspnet_Users] FOREIGN KEY([PatronID])
REFERENCES [dbo].[aspnet_Users] ([UserId])
GO

ALTER TABLE [dbo].[Requests] CHECK CONSTRAINT [FK_Requests_aspnet_Users]
GO

ALTER TABLE [dbo].[Requests]  WITH CHECK ADD  CONSTRAINT [FK_Requests_aspnet_Users1] FOREIGN KEY([LibraryFromID])
REFERENCES [dbo].[aspnet_Users] ([UserId])
GO

ALTER TABLE [dbo].[Requests] CHECK CONSTRAINT [FK_Requests_aspnet_Users1]
GO

ALTER TABLE [dbo].[Requests]  WITH CHECK ADD  CONSTRAINT [FK_Requests_aspnet_Users2] FOREIGN KEY([LibraryToID])
REFERENCES [dbo].[aspnet_Users] ([UserId])
GO

ALTER TABLE [dbo].[Requests] CHECK CONSTRAINT [FK_Requests_aspnet_Users2]
GO

ALTER TABLE [dbo].[Requests]  WITH CHECK ADD  CONSTRAINT [FK_Requests_Media] FOREIGN KEY([MediaID])
REFERENCES [dbo].[Media] ([MediaID])
GO

ALTER TABLE [dbo].[Requests] CHECK CONSTRAINT [FK_Requests_Media]
GO

