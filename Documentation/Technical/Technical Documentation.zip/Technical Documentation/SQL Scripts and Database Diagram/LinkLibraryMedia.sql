USE [C:\USERS\MISTERBRISTLES\DOCUMENTS\VISUAL STUDIO 2010\WEBSITES\FINALPROJECT\APP_DATA\ASPNETDB.MDF]
GO

/****** Object:  Table [dbo].[LinkLibraryMedia]    Script Date: 11/29/2016 11:54:33 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LinkLibraryMedia](
	[LibraryMediaID] [int] IDENTITY(1,1) NOT NULL,
	[LibraryID] [uniqueidentifier] NOT NULL,
	[MediaID] [int] NOT NULL,
	[QtyOwned] [int] NOT NULL,
	[QtyAvailable] [int] NOT NULL,
 CONSTRAINT [PK_LinkLibraryMedia] PRIMARY KEY CLUSTERED 
(
	[LibraryMediaID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[LinkLibraryMedia]  WITH CHECK ADD  CONSTRAINT [FK_LinkLibraryMedia_aspnet_Users] FOREIGN KEY([LibraryID])
REFERENCES [dbo].[aspnet_Users] ([UserId])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[LinkLibraryMedia] CHECK CONSTRAINT [FK_LinkLibraryMedia_aspnet_Users]
GO

ALTER TABLE [dbo].[LinkLibraryMedia]  WITH CHECK ADD  CONSTRAINT [FK_LinkLibraryMedia_Media] FOREIGN KEY([MediaID])
REFERENCES [dbo].[Media] ([MediaID])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[LinkLibraryMedia] CHECK CONSTRAINT [FK_LinkLibraryMedia_Media]
GO

