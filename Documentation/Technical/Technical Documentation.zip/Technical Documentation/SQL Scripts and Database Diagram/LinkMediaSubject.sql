USE [C:\USERS\MISTERBRISTLES\DOCUMENTS\VISUAL STUDIO 2010\WEBSITES\FINALPROJECT\APP_DATA\ASPNETDB.MDF]
GO

/****** Object:  Table [dbo].[LinkMediaSubject]    Script Date: 11/29/2016 11:55:14 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LinkMediaSubject](
	[MediaSubjectID] [int] IDENTITY(1,1) NOT NULL,
	[MediaID] [int] NOT NULL,
	[SubjectID] [int] NOT NULL,
 CONSTRAINT [PK_LinkMediaSubject] PRIMARY KEY CLUSTERED 
(
	[MediaSubjectID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[LinkMediaSubject]  WITH CHECK ADD  CONSTRAINT [FK_LinkMediaSubject_Media] FOREIGN KEY([MediaID])
REFERENCES [dbo].[Media] ([MediaID])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[LinkMediaSubject] CHECK CONSTRAINT [FK_LinkMediaSubject_Media]
GO

ALTER TABLE [dbo].[LinkMediaSubject]  WITH CHECK ADD  CONSTRAINT [FK_LinkMediaSubject_Subjects] FOREIGN KEY([SubjectID])
REFERENCES [dbo].[Subjects] ([SubjectID])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[LinkMediaSubject] CHECK CONSTRAINT [FK_LinkMediaSubject_Subjects]
GO

