USE [C:\USERS\MISTERBRISTLES\DOCUMENTS\VISUAL STUDIO 2010\WEBSITES\FINALPROJECT\APP_DATA\ASPNETDB.MDF]
GO

/****** Object:  Table [dbo].[LinkLibraryPatron]    Script Date: 11/29/2016 11:54:48 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LinkLibraryPatron](
	[LibraryCard] [int] IDENTITY(100000,1) NOT NULL,
	[LibraryID] [uniqueidentifier] NOT NULL,
	[PatronID] [uniqueidentifier] NOT NULL,
	[LateFees] [decimal](18, 2) NOT NULL,
 CONSTRAINT [PK_LinkLibraryPatron] PRIMARY KEY CLUSTERED 
(
	[LibraryCard] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[LinkLibraryPatron] ADD  CONSTRAINT [DF_LinkLibraryPatron_LateFees]  DEFAULT ((0)) FOR [LateFees]
GO

ALTER TABLE [dbo].[LinkLibraryPatron]  WITH CHECK ADD  CONSTRAINT [FK_LinkLibraryPatron_aspnet_Users] FOREIGN KEY([LibraryID])
REFERENCES [dbo].[aspnet_Users] ([UserId])
GO

ALTER TABLE [dbo].[LinkLibraryPatron] CHECK CONSTRAINT [FK_LinkLibraryPatron_aspnet_Users]
GO

ALTER TABLE [dbo].[LinkLibraryPatron]  WITH CHECK ADD  CONSTRAINT [FK_LinkLibraryPatron_aspnet_Users1] FOREIGN KEY([PatronID])
REFERENCES [dbo].[aspnet_Users] ([UserId])
GO

ALTER TABLE [dbo].[LinkLibraryPatron] CHECK CONSTRAINT [FK_LinkLibraryPatron_aspnet_Users1]
GO

