USE [C:\USERS\MISTERBRISTLES\DOCUMENTS\VISUAL STUDIO 2010\WEBSITES\FINALPROJECT\APP_DATA\ASPNETDB.MDF]
GO

/****** Object:  Table [dbo].[LinkMediaPublisher]    Script Date: 11/29/2016 11:55:06 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LinkMediaPublisher](
	[MediaPublisherID] [int] IDENTITY(1,1) NOT NULL,
	[MediaID] [int] NOT NULL,
	[PublisherID] [int] NOT NULL,
	[DatePublished] [date] NULL,
 CONSTRAINT [PK_LinkMediaPublisher] PRIMARY KEY CLUSTERED 
(
	[MediaPublisherID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[LinkMediaPublisher]  WITH CHECK ADD  CONSTRAINT [FK_LinkMediaPublisher_Media] FOREIGN KEY([MediaID])
REFERENCES [dbo].[Media] ([MediaID])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[LinkMediaPublisher] CHECK CONSTRAINT [FK_LinkMediaPublisher_Media]
GO

ALTER TABLE [dbo].[LinkMediaPublisher]  WITH CHECK ADD  CONSTRAINT [FK_LinkMediaPublisher_Publishers] FOREIGN KEY([PublisherID])
REFERENCES [dbo].[Publishers] ([PublisherID])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[LinkMediaPublisher] CHECK CONSTRAINT [FK_LinkMediaPublisher_Publishers]
GO

