USE [C:\USERS\MISTERBRISTLES\DOCUMENTS\VISUAL STUDIO 2010\WEBSITES\FINALPROJECT\APP_DATA\ASPNETDB.MDF]
GO

/****** Object:  Table [dbo].[Checkouts]    Script Date: 11/29/2016 11:53:18 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Checkouts](
	[CheckoutID] [int] IDENTITY(1,1) NOT NULL,
	[PatronID] [uniqueidentifier] NOT NULL,
	[MediaID] [int] NOT NULL,
	[DueDate] [date] NOT NULL,
	[Renewals] [int] NOT NULL,
 CONSTRAINT [PK_Checkouts] PRIMARY KEY CLUSTERED 
(
	[CheckoutID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Checkouts] ADD  CONSTRAINT [DF_Checkouts_Renewals]  DEFAULT ((0)) FOR [Renewals]
GO

ALTER TABLE [dbo].[Checkouts]  WITH CHECK ADD  CONSTRAINT [FK_Checkouts_aspnet_Users] FOREIGN KEY([PatronID])
REFERENCES [dbo].[aspnet_Users] ([UserId])
GO

ALTER TABLE [dbo].[Checkouts] CHECK CONSTRAINT [FK_Checkouts_aspnet_Users]
GO

ALTER TABLE [dbo].[Checkouts]  WITH CHECK ADD  CONSTRAINT [FK_Checkouts_Media] FOREIGN KEY([MediaID])
REFERENCES [dbo].[Media] ([MediaID])
GO

ALTER TABLE [dbo].[Checkouts] CHECK CONSTRAINT [FK_Checkouts_Media]
GO


