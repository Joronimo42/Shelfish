A few notes on the code...

-The method I used to access the database in almost every page was the SQLDataSource built into ASP.NET. You basically
 build your queries, then pass the parameters to them in the code behind. The method I used to do so was, whenever a 
 query would fire, I would access the SQLDataSource.Selecting or Updating or what have you event, and then use the 
 e as SQLDataSourceCommandArgs through e.Command.Parameters("@ParameterName").Value = ParameterValue. It's quick, it's easy,
 and it works for almost any query you can imagine. Also, it makes passing values programatically really easy.

-Another method that I used repeatedly throughout the program to access information was the Data.DataView method. 
 You take and create a DataView, which I always named "dview", then you initialize the dview with the following: 
	dview = CType(SQLDataSource.Select(DataSourceSelectArguments.Empty), Data.DataView)
 Using this method, you then have all the results of the SQL query in the form of a DataView, which can be easily accessed
 by treating it as a DataTable, through dview.Table. It also allows you to access columns by name, which is convient whenever
 you don't remember what order your query returns columns. For select queries with parameters, I used the method described 
 earlier.

-One problem that regularly occurs whenever moving the program to a different location is that Visual Studio 2010 will say, 
 "This project is not compatible with this version of Visual Studio."
 This is a lie. It says this because the project uses version 4.5 of the ASP.Net framework (for the email and phone number
 textbox validation). By default, Visual Studio 2010 will only open up to ASP.Net version 4.0, despite the fact that the 
 compiler is fully compatible with version 4.5. The easiest way around this is to change the web.config in the root directory
 to point to version 4.0, open the project, then change it back to 4.5. This is done in the following line:
	<compilation debug="true" strict="false" explicit="true" targetFramework="4.5">
 It's a really silly thing, and I don't understand why Microsoft does things like this. If you forget to change it back to 
 4.5, you'll get a build error, as 4.0 does not have the email and phone options for textboxes. 

-Also, the copy of the program provided has debug mode set to true, in a deployed state, this needs to be set to false. 

-Apart from all that, most of the documentation can be found in the .vb files behind each page, which can be found
 in the "Code Behind" folder. I purposefully tried to write a few comments on everything (apart from the repetitive stuff mentioned earlier.)
 In addition, the zip file contains a folder with all of the SQL scripts needed to recreate the database, in addition to a 
 diagram of the entire database. All of this combined should mean that the code is easy to maintain, if you have any questions,
 you can reach me at clintonj1015@warriormail.rlc.edu. 